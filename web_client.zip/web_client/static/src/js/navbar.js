/** @odoo-module **/

import {Component} from "@odoo/owl";

export class Navbar extends Component{
    static template = "app.Navbar";
}